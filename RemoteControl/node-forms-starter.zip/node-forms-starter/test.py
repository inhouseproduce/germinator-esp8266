# importing the requests library 
import requests 
import json

ssid = 'Dummy'
pw = 'Dummy'
minTemp = 0.0
maxTemp = 30.0
minHumid = 0.0
maxHumid = 100.0

# api-endpoint 
URL = "http://localhost:8081/test"

# location given here 
# location = "delhi technological university"

# PARAMS = {'address':location}

# sending get request and saving the response as response object 
r = requests.get(url = URL, params = None) 
  
data = r.text 

jsonParse = json.loads(data)
ssid_new = jsonParse["uuid"]
pw_new = jsonParse["password"]
minTemp_new = jsonParse["minTemp"]
maxTemp_new = jsonParse["maxTemp"]
minHumid_new = jsonParse["minHumid"]
maxHumid_new = jsonParse["maxHumid"]

if ssid != ssid_new or pw != pw_new:
    ssid = ssid_new
    pw = pw_new
if minTemp != minTemp_new or maxTemp != maxTemp_new:
    if minTemp_new < maxTemp_new: # Replace errvals
        if minTemp_new > 20.0:
            minTemp = minTemp_new
        if maxTemp_new < 30.0:
            maxTemp = maxTemp_new
if minHumid != minHumid_new or minHumid != minHumid_new:
    if minHumid_new < maxHumid_new: # Replace errvals
        if minHumid_new >= 0.0:
            minHumid = minHumid_new
        if maxHumid_new <= 100.0:
            maxHumid = maxHumid_new

print(ssid)
print(pw)
print(minTemp)
print(maxTemp)
print(minHumid)
print(maxHumid)