const express = require('express');
const http = require('http');
const router = express.Router();
message = "";

// router.get('/', (req, res) => {
//   res.render('contact');
// });

router.get('/', (req, res) => {
  res.render('contact', {
    data: {},
    errors: {}
  });
});

http.createServer(function (request, response) {
  // Send the HTTP header 
  // HTTP Status: 200 : OK
  // Content Type: text/plain
  const { method, url } = request;
  if(url == '/test') {
    response.writeHead(200, {'Content-Type': 'text/plain'});
    response.end(message);
  } else {
    response.end()
  }
}).listen(8081);

const { check, validationResult, matchedData } = require('express-validator');

router.post('/contact', [
  check('uuid')
    .isLength({ min: 1 })
    .withMessage('Wifi router is required')
    .trim(),
  check('password')
    .isLength({ min: 1 })
    .withMessage('Wifi password needed')
    .trim(),
  check('minTemp')
    .isLength({ min: 1 })
    .withMessage('Minimum Temperature Needed')
    .isNumeric()
    .withMessage('Error: must be a numeric value')
    .toFloat(),
  check('maxTemp')
    .isLength({ min: 1 })
    .withMessage('Maximum Temperature Needed')
    .isNumeric()
    .withMessage('Error: must be a numeric value')
    .toFloat(),
  check('minHumid')
    .isLength({ min: 1 })
    .withMessage('Minimum Humidity Needed')
    .isNumeric()
    .withMessage('Error: must be a numeric value')
    .toFloat(),
  check('maxHumid')
    .isLength({ min: 1 })
    .withMessage('Maximum Humidity Needed')
    .isNumeric()
    .withMessage('Error: must be a numeric value')
    .toFloat(),
], (req, res) => {
  const errors = validationResult(req);
  res.render('contact', {
    data: req.body,
    errors: errors.mapped()
  });

  const data = matchedData(req);
  message = JSON.stringify(data)
  console.log('Sanitized:', data);
});


module.exports = router;
